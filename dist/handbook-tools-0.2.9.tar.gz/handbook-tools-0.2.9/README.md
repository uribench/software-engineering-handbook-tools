[![Build Status](https://travis-ci.org/uribench/software-engineering-handbook-tools.svg?branch=master)](https://travis-ci.org/uribench/software-engineering-handbook-tools)
[![Maintainability](https://api.codeclimate.com/v1/badges/60f2e373b5ca64453968/maintainability)](https://codeclimate.com/github/uribench/software-engineering-handbook-tools/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/60f2e373b5ca64453968/test_coverage)](https://codeclimate.com/github/uribench/software-engineering-handbook-tools/test_coverage)

# Tools

A collection of automation scripts to build and maintain the `Handbook` directory of the 
[Software Engineering Handbook][1] repository.

---

[1]: https://github.com/uribench/software-engineering-handbook
